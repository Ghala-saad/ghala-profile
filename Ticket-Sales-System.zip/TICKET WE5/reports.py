import pandas as pd
import matplotlib.pyplot as plt

FILE_NAME = "tickets.csv"

#search by id
def search_ticket_by_id(ticket_id):
    try:
        df = pd.read_csv(FILE_NAME)
        result = df[df['Ticket ID'].astype(str) == str(ticket_id)]
        
        if result.empty:
            print(f"\nTicket ID ({ticket_id}) not found in the system.")
        else:
            print(f"\n==================== Search Result ({ticket_id}) ====================")
            print(result.to_string(index=False))
            print("=========================================================================")
    except FileNotFoundError:
        print("\nData file not found.")

#reports and avg, max and min
def generate_sales_summary_reports():
    try:
        df = pd.read_csv(FILE_NAME)
        if df.empty:
            print("\nFile is empty. Cannot generate reports.")
            return

        print("\n==========================================================")
        print("                Sales Summary Reports                     ")
        print("==========================================================")
        
        
        avg_cost = df['Total Cost'].mean()
        max_cost = df['Total Cost'].max()
        min_cost = df['Total Cost'].min()
        total_revenue = df['Total Cost'].sum()
        
        
        avg_qty = df['Quantity'].mean()
        max_qty = df['Quantity'].max()
        min_qty = df['Quantity'].min()
        total_tickets_sold = df['Quantity'].sum()

        print(f"Total Revenue: {total_revenue:,.2f} SAR")
        print(f"Total Tickets Sold: {total_tickets_sold} tickets")
        print(f"Average Ticket Sales (Cost): {avg_cost:,.2f} SAR | (Quantity): {avg_qty:.1f}")
        print(f"Maximum Ticket Sale  (Cost): {max_cost:,.2f} SAR | (Quantity): {max_qty}")
        print(f"Minimum Ticket Sale  (Cost): {min_cost:,.2f} SAR | (Quantity): {min_qty}")
        print("----------------------------------------------------------")

        #report per event
        print("\n[Sales Summary per Event]:")
        event_summary = df.groupby('Event Name').agg({'Quantity': 'sum', 'Total Cost': 'sum'}).reset_index()
        print(event_summary.to_string(index=False))
        print("----------------------------------------------------------")

        #report per date
        print("\n[Sales Over Time]:")
        date_summary = df.groupby('Date of Purchase').agg({'Quantity': 'sum', 'Total Cost': 'sum'}).reset_index()
        print(date_summary.to_string(index=False))
        print("==========================================================")

    except FileNotFoundError:
        print("\nData file not found.")

#charts
def show_sales_chart():
    try:
        df = pd.read_csv(FILE_NAME)
        if df.empty:
            print("\nFile is empty. Cannot generate chart.")
            return
        
        
        event_data = df.groupby('Event Name')['Total Cost'].sum()
        
        
        df['Date of Purchase'] = pd.to_datetime(df['Date of Purchase'])
        date_data = df.groupby('Date of Purchase')['Total Cost'].sum().sort_index()
        
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
        
        #bar Chart
        event_data.plot(kind='bar', color='skyblue', edgecolor='black', ax=ax1)
        ax1.set_title('Total Revenue per Event (Bar Chart)', fontweight='bold')
        ax1.set_xlabel('Event Name')
        ax1.set_ylabel('Total Revenue (SAR)')
        ax1.tick_params(axis='x', rotation=45)
        
        #line chart
        date_data.plot(kind='line', marker='o', color='green', linewidth=2, ax=ax2)
        ax2.set_title('Sales Over Time (Line Chart)', fontweight='bold')
        ax2.set_xlabel('Date of Purchase')
        ax2.set_ylabel('Total Revenue (SAR)')
        ax2.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        print("\nOpening charts window...")
        
    except FileNotFoundError:
        print("\nData file not found.")

if __name__ == "__main__":
    print("--- Running Test Commands for Student 5 Features ---")
    
    # 1. Test statistical reports (Average, Max, Min for Cost and Quantities)
    generate_sales_summary_reports()
    
    # 2. Test visualizations (Bar chart for Events & Line chart for Sales over time)
    show_sales_chart()
    
    # 3. Test search function
    search_ticket_by_id("1")
