from menu import main_menu
def user_login():
    print("Welcome to Ticket Sales Management System!")
    
    username = input("Username:")
    password = input("Password:")

    if username == "admin" and password == "admin123":
        print("Login Successful!\n")
        return True

    else:
        print("Wrong credentials, try again.")
        return False


def main():
    if user_login():
        print("System started ..")
        main_menu()
    else:
        print ("Program closed.")

main()
