import pandas as pd

FILE_NAME = "tickets.csv"

def view_all_tickets():
    try:
        df = pd.read_csv(FILE_NAME)
        if df.empty:
            print("\n--- No tickets stored in the system currently ---")
        else:
            print("\n==================== View All Tickets ====================")
            print(df.to_string(index=False))
            print("===========================================================")
    except FileNotFoundError:
        columns = ['Ticket ID', 'Event Name', 'Customer Name', 'Date of Purchase', 'Ticket Price', 'Quantity', 'Total Cost']
        new_df = pd.DataFrame(columns=columns)
        new_df.to_csv(FILE_NAME, index=False)
        print("\n--- Empty file created successfully ---")

def save_ticket_to_csv(ticket_data):
    try:
        df = pd.read_csv(FILE_NAME)
    except FileNotFoundError:
        columns = ['Ticket ID', 'Event Name', 'Customer Name', 'Date of Purchase', 'Ticket Price', 'Quantity', 'Total Cost']
        df = pd.DataFrame(columns=columns)
    
    new_row = pd.DataFrame([ticket_data])
    updated_df = pd.concat([df, new_row], ignore_index=True)
    updated_df.to_csv(FILE_NAME, index=False)
    print(f"\nTicket ID ({ticket_data['Ticket ID']}) saved successfully!")

