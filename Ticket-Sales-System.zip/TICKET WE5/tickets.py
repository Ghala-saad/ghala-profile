from datetime import datetime
#Function to collect ticket sales data from the user, validate inputs, and calculate the total cost.
def add_ticket_details():
    print("\nEnter Ticket Details")

    try:
        ticket_id = input("Enter Ticket ID: ").strip()
        event_name = input("Enter Event Name: ").strip()
        customer_name = input("Enter Customer Name: ").strip()
        purchase_date = input("Enter Date of Purchase (YYYY-MM-DD): ").strip()

        if not ticket_id or not event_name or not customer_name or not purchase_date:
            print("All fields are required")
            return None

        try:
            datetime.strptime(purchase_date, "%Y-%m-%d")
        except ValueError:
            print("Invalid date format. Use YYYY-MM-DD")
            return None

        ticket_price = float(input("Enter Ticket Price: "))
        quantity = int(input("Enter Quantity: "))

        if ticket_price <= 0 or quantity <= 0:
            print("Price and Quantity must be positive")
            return None

        total_cost = ticket_price * quantity

        ticket_data = {
            "Ticket ID": ticket_id,
            "Event Name": event_name,
            "Customer Name": customer_name,
            "Date of Purchase": purchase_date,
            "Ticket Price": ticket_price,
            "Quantity": quantity,
            "Total Cost": total_cost
        }

        print(f"Total Cost: {total_cost:,.2f} SAR")
        return ticket_data

    except ValueError:
        print("Please enter valid numbers for Price and Quantity")
        return None