import pandas as pd
import matplotlib.pyplot as plt
from tickets import add_ticket_details
from save import save_ticket_to_csv, view_all_tickets
from reports import (
    search_ticket_by_id,
    generate_sales_summary_reports,
    show_sales_chart
)


def main_menu():
    while True:
        print("\n================ MAIN MENU ================")
        print("1. Add Ticket")
        print("2. View All Tickets")
        print("3. Search Ticket by ID")
        print("4. Sales Summary Reports")
        print("5. Show Charts")
        print("6. Exit")
        print("==========================================")

        choice = input("Enter your choice: ")

        if choice == "1":
            ticket = add_ticket_details()
            if ticket:
                save_ticket_to_csv(ticket)

        elif choice == "2":
            view_all_tickets()

        elif choice == "3":
            ticket_id = input("Enter Ticket ID to search: ")
            search_ticket_by_id(ticket_id)

        elif choice == "4":
            generate_sales_summary_reports()

        elif choice == "5":
            show_sales_chart()

        elif choice == "6":
            print("Exiting system... Goodbye!")
            break

        else:
            print("Invalid choice, try again.")


if __name__== "__main__":
    main_menu()
